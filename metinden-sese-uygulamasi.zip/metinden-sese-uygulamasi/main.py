#Aşağıdaki modülleri içeri aktararak önce bilgisayarımızdaki tts motorunu kontrol etmek için gerekli kütüphaneyi kuruyoruz. Bununla #birlikte os modülünü import ederek ise dosya varlığını kontrol edebilmemizi sağlıyoruz.
#pyttsx3 modülünü kurmak için önce bilgisayarımıza pip install pyttsx3 şeklinde kodu cmd üzerinden yazmamız gerekiyor. 
#pip python programlama dilinde paket yöneticisidir ve pip install şeklinde farklı kütüphanelerdeki modülleri kurabiliriz. 

import pyttsx3
import os

#Bu uygulama girdiğiniz metin içeriklerini bilgisayarınızdaki sapi5 arabirimi üzerinden metinden sese çevirme yapabilmektedir.
#Önce uygulama giriş alanında veri olduğu müddetçe veya enter tuşuna basıldığı müddetçe aktif olmasını sağlıyoruz.

while True:
    kullanici_tercih_secimi = input("Uygulamada metin çevirmek için  M tuşuna basınız ve metin alanını karşınıza getiriniz. Çıkmak için ise q harfine basınız. Veya yardım almak için h tuşuna basınız.")
    if kullanici_tercih_secimi == "q":
        print("Uygulamadan çıkılıyor kapatmak için enter tuşuna basın")
        break;
    elif kullanici_tercih_secimi == "h":
        yardim_talimatlari = """
        ****\n
        Bu uygulama ile metinlerinizi sese çevirebilirsiniz. Özellikleri aşağıdaki gibidir;\n
        *Metin alanına girilen içerik bilgisayarınızdaki sesler ile mp3 ses dosyasına çevirilmektedir. Bu sistem sapi5 metinden sese çeviri altyapısını kullanmaktadır.
        *Reg dosyasını çalıştırarak windows türkçe seslerinden yararlanabilirsiniz.
        *Denetim masasında metinden konuşma ayarlarına gidiniz ve ses seçim alanında microsoft tolgayı seçiniz.  
        ****
        """
        print(yardim_talimatlari)
        input()
    elif kullanici_tercih_secimi == "m":
        cevirilecek_metin = input(" Yapay insan sesine çevirmek istediğiniz metni girin ve enter tuşuna basın")
        engine = pyttsx3.init("sapi5")
        #Yukarıda sapi5 altyapısını kullanmasını sağlıyoruz modülün
        sesler = engine.getProperty("voices")
        engine.setProperty("sesler",sesler[0])
        #Önce bilgisayarımızdaki seslerin bilgilerini çekiyoruz getProperty ile sonra bu sesler bir dizi şeklinde çekildiği için setProperty ile  sesler[0] şeklinde kurulu ve aktif olan ilk sesi seçiyoruz.   
        engine.save_to_file(cevirilecek_metin,"cevirilmis_icerik.mp3")
        engine.runAndWait()
        #Ses çeviri işlemi için çalıştırma ve çeviri işleminin beklenmesi adına runAndWait komutunu veriyoruz.
        if os.path.isfile("cevirilmis_icerik.mp3"):
            print("Çevirme işlemi başarılı")
            input()
        else:
            print("Tekrar deneyiniz")
            input()
#os.path.isfile komutu ile dosya varlığını sorguluyoruz.