#Bu uygulama ile giriş alanına girdiğiniz veri türüne ilişkin methodları o veri türünün adıyla .txt uzantısıyla saklamaktadır.
#Örneğin : str yazdığınızda str.txt aynı dizin içerisinde oluşturulmuş olacaktır.

import os

while True: 
    uygulama_baslatma = input("Uygulamayı başlatmak için enter çıkmak için q harfine basınız")
    if uygulama_baslatma == "q":
        print("Uygulamadan çıkılıyor")
        input()
        break
    else:
        veri_turu_tercihi = input("Methodunu sorgulamak için veri türünü giriniz. Örneğin : string için str ")
    dosya = open(veri_turu_tercihi+".txt","w+")    
    if os.path.isfile(veri_turu_tercihi+".txt"):
        print(f"{veri_turu_tercihi} methodları  dosyaya yazıldı!")
        input()
#Yukarıdaki koşullu durum ile uygulamadan çıkmak için q tuşuna basılması halinde ne olacağı tanımlandı.
# Else durumunda ise uygulamanın kullanıcı tarafından veri türüne göre çıktı alabilmesi için gerekli kodlar tanımlandı.    
        for i in dir(veri_turu_tercihi):#dir() fonksiyonu yukarıda kullanıcı tarafından alınan veri türüne göre methodları çekmek için kullanıldı. 
            if "__" not in i:
                print(i,sep="\n",file=dosya)            
#if kontrolü ile sadece işimize yarayacak methodlar çekildi. İşimize yarayacak methodlar başında __ olmayan methodlardır. 
       
        