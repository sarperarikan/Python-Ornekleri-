#Bu uygulama ile giriş alanına girdiğiniz veri türüne ilişkin methodları o veri türünün adıyla .txt uzantısıyla saklamaktadır.
#Örneğin : str yazdığınızda str.txt aynı dizin içerisinde oluşturulmuş olacaktır.

import os

while True: 
    uygulama_baslatma = input("Uygulamayı başlatmak için enter çıkmak için q harfine basınız")
    if uygulama_baslatma == "q":
        print("Uygulamadan çıkılıyor")
        input()
        break
    else:
        veri_turu_tercihi = input("Methodunu sorgulamak için veri türünü giriniz. Örneğin : string için str veya yardım almak için y tuşuna basınız.")
        if veri_turu_tercihi == "str":
                dosya = open(veri_turu_tercihi+".txt","w+")
                for i in dir(str()):#dir() içerisine string methodları için str() parametresi verildi. 
                        if "__" not in i:
                                print(i,sep="\n",file=dosya)             
        elif veri_turu_tercihi == "tuple":
                dosya = open(veri_turu_tercihi+".txt","w+")
                for i in dir(tuple()):#dir() içerisine tuple veri türünü listelemek için tuple() parametre olarak verildi. 
                        if "__" not in i:
                                print(i,sep="\n",file=dosya)            
        elif veri_turu_tercihi == "int":
                dosya = open(veri_turu_tercihi+".txt","w+")
                for i in dir(int()):#dir() içerisine int() veri türü parametre olarak verildi. 
                        if "__" not in i:
                                print(i,sep="\n",file=dosya)            
        elif veri_turu_tercihi == "list":
                dosya = open(veri_turu_tercihi+".txt","w+")
                for i in dir(list()):#dir() parametre olarak list veri türü verildi. 
                        if "__" not in i:
                                print(i,sep="\n",file=dosya)            
        elif veri_turu_tercihi == "float":
                dosya = open(veri_turu_tercihi+".txt","w+")
                for i in dir(type(float())):#dir() float türü parametre olarak verildi. 
                        if "__" not in i:
                                print(i,sep="\n",file=dosya)            
        elif veri_turu_tercihi == "set":
                dosya = open(veri_turu_tercihi+".txt","w+")
                for i in dir(type(set())):#dir() set veri tipi parametre olarak verildi. 
                        if "__" not in i:
                                print(i,sep="\n",file=dosya)            
        elif veri_turu_tercihi == "range" :
                dosya = open(veri_turu_tercihi+".txt","w+")
                for i in dir(type(range(10))):#dir() range veri türü olarak parametre olarak verildi. 
                        if "__" not in i:
                                print(i,sep="\n",file=dosya)            
        elif veri_turu_tercihi == "frozenset":
                dosya = open(veri_turu_tercihi+".txt","w+")
                for i in dir(type(frozenset())):#dir() frozenset veri türü parametre olarak verildi. 
                        if "__" not in i:
                                print(i,sep="\n",file=dosya)            
        elif veri_turu_tercihi == "y":
                yardim_metni = """
Veri türleri girişlerini aşağıdaki gibi yapabilirsiniz:\n
*str = string\n
*int = integer\n
*tuple = tuple\n
*set = set\n
*frozenset = frozenset\n
*float = float\n

                """
                print(yardim_metni)
                input()
        else:
                print("Girdiğiniz geçerli bir veri türü olmayabilir. Lütfen veri türü giriş ekranında y harfine basarak geçerli türler hakkında bilgi alabilirsiniz.")
                input()


#Yukarıdaki koşullar veri türüne göre method listelenebilmesi için oluşturulmuştur.  





    if os.path.isfile(veri_turu_tercihi+".txt"):
        print(f"{veri_turu_tercihi} methodları  dosyaya yazıldı!")
        input()

